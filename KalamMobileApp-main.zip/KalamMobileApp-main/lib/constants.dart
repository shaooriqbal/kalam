class appConstants {
  String APIURL = 'http://lebaneseopinion.arraytag.com/election_app/api/';
}