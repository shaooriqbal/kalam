export 'home_page/export.dart';
export 'login_page/export.dart';
export 'splash_page/export.dart';
export 'voting_page//export.dart';
export 'candidate_page/export.dart';
export 'settings_page/export.dart';